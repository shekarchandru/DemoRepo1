create table Library
(
id int primary key,
name varchar(50),
commaSperatedBooknames varchar(100)
);
insert into Library values(1,'JLNehru','Book1');