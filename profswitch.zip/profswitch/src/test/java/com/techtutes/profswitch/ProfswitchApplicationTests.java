package com.techtutes.profswitch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfswitchApplicationTests {

	@Test
	void contextLoads() {
	}

}
