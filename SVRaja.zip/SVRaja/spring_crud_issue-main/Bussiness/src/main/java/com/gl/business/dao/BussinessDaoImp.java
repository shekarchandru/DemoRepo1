package com.gl.business.dao;

import java.util.List;

import javax.transaction.Transactional;
import javax.persistence.criteria.CriteriaQuery;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.gl.business.model.Bussiness;

@Repository
public class BussinessDaoImp implements BussinessDao {
	@Autowired
	SessionFactory factory;

	@Override
	@Transactional
	public void save(Bussiness bussiness) {
		
		Session currentSession = factory.getCurrentSession();
		Transaction tx = currentSession.beginTransaction();
		currentSession.saveOrUpdate(bussiness);
		  tx.commit();
	}

	@Override
	@Transactional
	public List<Bussiness> findAll() {
//		System.out.println("Ho");
	    Session currentSession = factory.getCurrentSession();
	  //  Transaction tx = currentSession.beginTransaction();
	  //  Criteria c = currentSession.createCriteria(Bussiness.class);
	    List <Bussiness> businesses = currentSession.createQuery("from Bussiness").list();
	  //  tx.commit();
		return businesses;
	}
	

}
